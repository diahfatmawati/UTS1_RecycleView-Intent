package com.example.uts1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val data = createFac()
        listRecyclerView.layoutManager = LinearLayoutManager(this)
        listRecyclerView.setHasFixedSize(true)
        listRecyclerView.adapter = AdapterFakultas(data, { onItem: DataFakultas ->
            onItemClicked(onItem) })
    }
    private fun onItemClicked(onItem: DataFakultas) {
        val showDetailActivityIntent = Intent(this, DetailFakultas::class.java)
        showDetailActivityIntent.putExtra(Intent.EXTRA_TEXT, onItem.imgFak)
        showDetailActivityIntent.putExtra(Intent.EXTRA_TITLE, onItem.nameFak)
        showDetailActivityIntent.putExtra(Intent.EXTRA_TEMPLATE, onItem.descFak)
        showDetailActivityIntent.putExtra(Intent.EXTRA_SUBJECT, onItem.descDet)
        startActivity(showDetailActivityIntent)
    }
    private fun createFac(): List<DataFakultas> {
        val List = ArrayList<DataFakultas>()
        List.add(
            DataFakultas(
                R.drawable.upn,
                "Fakultas Ilmu Komputer",
                "Fakultas Ilmu Komputer\n" +
                        "adalah satu dari dari 7\n" +
                        "program studi di UPN\n" +
                        "VETERAN JATIM",
                "1. Teknik Informatika\n" +
                        "2. Sistem Informasi"
            )
        )
        List.add(
            DataFakultas(
                R.drawable.upn,
                "Fakultas Teknik",
                "Fakultas Teknik\n" +
                        "merupakan salah satu dari 7\n" +
                        "Fakultas 'Veteran' Jawa\n" +
                        "Timur. Yang terdiri dari program\n" +
                        "studi: ",
                "1. Teknik Kimia\n" +
                        "2. Teknik Industri\n" +
                        "3. Teknik Sipil\n" +
                        "4. Teknik Lingkungan\n" +
                        "5. Teknologi Pangan"
            )
        )
        List.add(
            DataFakultas(
                R.drawable.upn,
                "Fakultas Ekonomi dan Bisnis",
                "Fakultas Ekonomi dan Bisnis\n" +
                        "merupakan salah satu dari 7\n" +
                        "Fakultas 'Veteran' Jawa\n" +
                        "Timur. Yang terdiri dari program\n" +
                        "studi: ",
                "1. Ekonomi Pembangunan\n" +
                        "2. Akuntansi\n" +
                        "3. Manajemen"
            )
        )
        List.add(
            DataFakultas(
                R.drawable.upn,
                "Fakultas Pertanian",
                "Fakultas Pertanian\n" +
                        "merupakan salah satu dari 7\n" +
                        "Fakultas 'Veteran' Jawa\n" +
                        "Timur. Yang terdiri dari program\n" +
                        "studi: ",
                "1. Agroteknologi\n" +
                        "2. Agribisnis"
            )
        )
        List.add(
            DataFakultas(
                R.drawable.diah,
                "Diah's Profile",
                "Nama : Diah Fatmawati\n"+
                        "Tempat,Tanggal Lahir : Surabaya, 19 Juli 2000\n" +
                        "Alamat : Surabaya, Jawa Timur\n" +
                        "No Telepon : 083857667563\n" +
                        "Email : fadiahachmad@gmail.com\n" +
                        "Github : https://github.com/diahfatma\n",
                "Riwayat Pendidikan : \n" +
                        "\t\t 1. TK Baitusalam \n" +
                        "\t\t 2. SDN Manukan Kulon 6 \n" +
                        "\t\t 3. SMPN 33 Surabaya \n" +
                        "\t\t 4. SMA SHAFTA Surabaya \n\n" +
                        "Penghargaan : \n" +
                        "\t\t 1. Juara 3 Membuat dan Baca Puisi \n" +
                        "\t\t 2. Juara 3 Menulis CERPEN \n" +
                        "\t\t 3. 10 Besar CYS kategori Enviromental\n\n"
            )
        )
        return List
    }
}