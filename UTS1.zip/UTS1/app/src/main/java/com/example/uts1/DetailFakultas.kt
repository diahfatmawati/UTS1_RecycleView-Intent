package com.example.uts1

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.detail_fakultas.*

class DetailFakultas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detail_fakultas)
        val intentThatStartedThisActivity = getIntent()
        if (intentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT)) {
            val imgF = intentThatStartedThisActivity.getIntExtra(Intent.EXTRA_TEXT, 0)
            val nameF =
                intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TITLE)
            val deskF =
                intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEMPLATE)
            val deskS =
                intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_SUBJECT)
            imageFakultas.setImageResource(imgF)
            NamaFakultas.text = nameF
            DeskripsiFakultas.text = deskF
            Deskripsi.text = deskS
        }
    }
}
