package com.example.uts1

class DataFakultas (val imgFak: Int, val nameFak: String, val descFak: String, val descDet: String)